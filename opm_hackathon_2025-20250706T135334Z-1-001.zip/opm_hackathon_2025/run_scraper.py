"""Enhanced script to run the HSSE news scraper with categorization"""

import os
import sys
import json
from datetime import datetime
from main import HSSENewsScraperOrchestrator

def main():
    """Main function to run the enhanced scraper"""
    
    # Check for API key
    api_key = os.getenv('OPENAI_API_KEY')
    if not api_key:
        print("❌ Error: OPENAI_API_KEY environment variable not set")
        print("Please create a .env file with your OpenAI API key")
        sys.exit(1)
    
    print("🇬🇾 HSSE News Incident Detection & Categorization System for Guyana")
    print("=" * 70)
    print(f"🕐 Started at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print()
    print("📋 Categories: Near Miss, Minor Incident, Recordable Incident, LTI, Fatality, Major Environmental Spill")
    print("📋 Types: Injury/Illness, Property Damage, Environmental Incident, Security Breach, Unsafe Act/Condition, Fire/Explosion")
    
    # Initialize scraper
    scraper = HSSENewsScraperOrchestrator(api_key)
    
    # Get number of articles to scrape
    try:
        limit = int(input("\nEnter articles to scrape per site (default 10): ") or "10")
    except ValueError:
        limit = 10
    
    print(f"\n🎯 Scraping {limit} articles per news site...")
    
    # Run the scraper
    incidents = scraper.run(limit_per_site=limit)
    
    # Export results
    if incidents:
        # Export detailed results
        detailed_export = scraper.export_results(incidents)
        
        # Export clean database-ready data
        database_export = scraper.export_for_database(incidents)
        
        # Save files
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        
        # Detailed results file
        detailed_filename = f'hsse_detailed_results_{timestamp}.json'
        with open(detailed_filename, 'w') as f:
            json.dump(detailed_export, f, indent=2, default=str)
        
        # Database-ready file
        database_filename = f'hsse_database_ready_{timestamp}.json'
        with open(database_filename, 'w') as f:
            json.dump(database_export, f, indent=2, default=str)
        
        print(f"\n💾 Results saved:")
        print(f"   📄 Detailed results: {detailed_filename}")
        print(f"   🗄️  Database ready: {database_filename}")
        print(f"🎯 Found {len(incidents)} HSSE incidents")
        
        # Show categorization summary
        print(f"\n📊 CATEGORIZATION SUMMARY:")
        categories = {}
        types = {}
        
        for _, analysis in incidents:
            cat = analysis.category
            typ = analysis.incident_type
            categories[cat] = categories.get(cat, 0) + 1
            types[typ] = types.get(typ, 0) + 1
        
        print(f"   Categories: {dict(categories)}")
        print(f"   Types: {dict(types)}")
        
    else:
        print(f"\n✅ No HSSE incidents detected!")
    
    print(f"✅ Analysis complete!")

if __name__ == "__main__":
    main()