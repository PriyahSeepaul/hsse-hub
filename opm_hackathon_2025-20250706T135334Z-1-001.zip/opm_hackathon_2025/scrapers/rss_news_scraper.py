"""RSS-based news scraper implementation"""

import feedparser
import requests
from bs4 import BeautifulSoup
from typing import List, Optional
from datetime import datetime
import time

from scrapers.base_news_scraper import BaseNewsScraper
from models import NewsArticle
from utils import KeywordMatcher, TextProcessor, URLHandler
from config import Config

class RSSNewsScraper(BaseNewsScraper):
    """RSS-based scraper for news sites"""
    
    def __init__(self, site_config: dict):
        super().__init__(site_config)
        self.keyword_matcher = KeywordMatcher()
        self.text_processor = TextProcessor()
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
    
    def scrape_articles(self, limit: int = Config.DEFAULT_LIMIT) -> List[NewsArticle]:
        """Scrape articles using RSS feed"""
        articles = []
        
        try:
            # Parse RSS feed
            feed = feedparser.parse(self.site_config.get('rss_url', ''))
            
            if not feed.entries:
                print(f"No entries found in RSS feed for {self.name}")
                return articles
            
            print(f"Found {len(feed.entries)} entries in {self.name} RSS feed")
            
            for entry in feed.entries[:limit]:
                try:
                    # Quick relevance check on title and summary
                    title = entry.get('title', '')
                    summary = entry.get('summary', '')
                    
                    if self.keyword_matcher.is_hsse_relevant(title + ' ' + summary):
                        article = self.parse_article(entry.link)
                        if article:
                            articles.append(article)
                            print(f"✓ Scraped: {article.title[:60]}...")
                    
                    time.sleep(Config.REQUEST_DELAY)
                    
                except Exception as e:
                    print(f"Error processing entry: {e}")
                    continue
            
            self.articles_scraped = len(articles)
            print(f"Scraped {len(articles)} relevant articles from {self.name}")
            
        except Exception as e:
            print(f"Error scraping RSS feed for {self.name}: {e}")
        
        return articles
    
    def parse_article(self, article_url: str) -> Optional[NewsArticle]:
        """Parse a single article from its URL"""
        try:
            response = requests.get(article_url, headers=self.headers, timeout=Config.TIMEOUT)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.content, 'html.parser')
            
            # Extract article components
            title = self._extract_title(soup)
            content = self._extract_content(soup)
            images = self._extract_images(soup)
            pub_date = self._extract_date(soup)
            
            if not title or not content:
                return None
            
            # Final relevance check on full content
            if not self.keyword_matcher.is_hsse_relevant(title + ' ' + content):
                return None
            
            article = NewsArticle(
                title=self.text_processor.clean_text(title),
                content=self.text_processor.clean_text(content),
                url=article_url,
                source=self.name,
                published_date=pub_date,
                images=images,
                summary=self.text_processor.extract_summary(content)
            )
            
            return article
            
        except Exception as e:
            print(f"Error parsing article {article_url}: {e}")
            return None
    
    def _extract_title(self, soup: BeautifulSoup) -> str:
        """Extract article title"""
        selectors = self.site_config['selectors']['title'].split(', ')
        
        for selector in selectors:
            element = soup.select_one(selector)
            if element:
                return element.get_text(strip=True)
        
        # Fallback to page title
        title_tag = soup.find('title')
        return title_tag.get_text(strip=True) if title_tag else ''
    
    def _extract_content(self, soup: BeautifulSoup) -> str:
        """Extract article content"""
        selectors = self.site_config['selectors']['content'].split(', ')
        
        for selector in selectors:
            elements = soup.select(selector)
            if elements:
                # Get text from all matching elements
                content = ' '.join([elem.get_text(strip=True) for elem in elements])
                if len(content) > 100:  # Minimum content length
                    return content
        
        return ''
    
    def _extract_images(self, soup: BeautifulSoup) -> List[str]:
        """Extract article images"""
        images = []
        selectors = self.site_config['selectors']['image'].split(', ')
        
        for selector in selectors:
            img_elements = soup.select(selector)
            for img in img_elements:
                src = img.get('src') or img.get('data-src')
                if src:
                    absolute_url = URLHandler.make_absolute_url(src, self.base_url)
                    if absolute_url not in images:
                        images.append(absolute_url)
        
        return images
    
    def _extract_date(self, soup: BeautifulSoup) -> Optional[datetime]:
        """Extract publication date"""
        selectors = self.site_config['selectors']['date'].split(', ')
        
        for selector in selectors:
            element = soup.select_one(selector)
            if element:
                date_str = element.get_text(strip=True)
                # Try to parse date (simplified)
                try:
                    return datetime.strptime(date_str, '%Y-%m-%d')
                except:
                    pass
        
        return None