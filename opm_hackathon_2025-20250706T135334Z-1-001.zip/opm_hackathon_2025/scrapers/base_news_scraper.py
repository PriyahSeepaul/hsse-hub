"""Base news scraper class"""

from abc import ABC, abstractmethod
from typing import List, Optional
from models import NewsArticle

class BaseNewsScraper(ABC):
    """Abstract base class for news scrapers"""
    
    def __init__(self, site_config: dict):
        self.site_config = site_config
        self.name = site_config['name']
        self.base_url = site_config['base_url']
        self.articles_scraped = 0
    
    @abstractmethod
    def scrape_articles(self, limit: int = None) -> List[NewsArticle]:
        """Scrape articles from the news site"""
        pass
    
    @abstractmethod
    def parse_article(self, article_url: str) -> Optional[NewsArticle]:
        """Parse a single article from its URL"""
        pass
    
    def get_stats(self) -> dict:
        """Get scraping statistics"""
        return {
            'scraper': self.name,
            'articles_scraped': self.articles_scraped,
            'base_url': self.base_url
        }