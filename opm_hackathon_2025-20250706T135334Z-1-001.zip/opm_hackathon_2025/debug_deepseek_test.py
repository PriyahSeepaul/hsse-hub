"""Debug script to test DeepSeek categorization with hardcoded sample articles"""

from datetime import datetime
from models import NewsArticle
from deepseek_analyzer import DeepSeekHSSEAnalyzer

def create_sample_articles():
    """Create hardcoded sample articles for testing"""
    
    sample_articles = [
        NewsArticle(
            title="Construction Worker Hospitalized After Fall at Georgetown Site",
            content="A construction worker was rushed to Georgetown Public Hospital after falling from scaffolding at a building site on Regent Street yesterday. The worker, identified as John Smith, 32, fell approximately 15 feet and sustained serious injuries to his back and legs. He is expected to remain hospitalized for several days. The Ministry of Labour has launched an investigation into the incident. Site supervisor reported that the worker was wearing a safety harness at the time of the fall.",
            url="https://guyanachronicle.com/sample1",
            source="Guyana Chronicle",
            published_date=datetime(2025, 1, 15),
            summary="Construction worker hospitalized after fall from scaffolding at Georgetown construction site."
        ),
        
        NewsArticle(
            title="Minor Fire Extinguished at Bauxite Processing Plant",
            content="A small fire broke out at the Berbice Bauxite processing facility early this morning but was quickly contained by the site's emergency response team. No injuries were reported, and the fire was extinguished within 30 minutes. The incident occurred in the electrical equipment room and caused minimal damage to machinery. Operations resumed normal schedule after safety inspections. The company's safety officer stated that all emergency protocols were followed correctly.",
            url="https://stabroeknews.com/sample2", 
            source="Stabroek News",
            published_date=datetime(2025, 1, 14),
            summary="Minor fire at bauxite plant quickly contained with no injuries."
        ),
        
        NewsArticle(
            title="Factory Worker Dies in Machinery Accident",
            content="A tragic accident at the Diamond Sugar Factory claimed the life of a 45-year-old worker yesterday evening. The worker, whose name has not been released pending family notification, was caught in conveyor belt machinery during routine maintenance. Emergency services responded immediately but the worker was pronounced dead at the scene. The factory has been temporarily shut down while authorities investigate. This is the second workplace fatality at the facility in three years.",
            url="https://guyanachronicle.com/sample5",
            source="Guyana Chronicle",
            published_date=datetime(2025, 1, 11),
            summary="Factory worker dies in machinery accident during maintenance."
        )
    ]
    
    return sample_articles

def test_deepseek_categorization():
    """Test DeepSeek categorization with sample articles"""
    
    print("🤖 TESTING DEEPSEEK CATEGORIZATION WITH SAMPLE ARTICLES")
    print("=" * 70)
    print("Testing how DeepSeek categorizes different types of HSSE incidents...")
    print()
    
    # Create analyzer - you can choose which model to use
    print("🔧 Available models:")
    print("   1. deepseek-r1:8b (faster, less accurate)")
    print("   2. deepseek-r1:32b (slower, more accurate)")
    
    choice = input("\nChoose model (1 or 2, default 1): ").strip()
    
    if choice == "2":
        model_name = "deepseek-r1:32b"
        print("🚀 Using DeepSeek-R1 32B model")
    else:
        model_name = "deepseek-r1:8b"
        print("🚀 Using DeepSeek-R1 8B model")
    
    analyzer = DeepSeekHSSEAnalyzer(model_name=model_name)
    
    # Get sample articles
    sample_articles = create_sample_articles()
    
    results = []
    
    for i, article in enumerate(sample_articles, 1):
        print(f"\n🔬 Testing Article {i}/{len(sample_articles)}")
        print(f"📰 Title: {article.title}")
        print(f"📅 Date: {article.published_date.strftime('%Y-%m-%d')}")
        print(f"🔗 Source: {article.source}")
        print("🤖 Analyzing with DeepSeek...")
        
        # Analyze with DeepSeek
        try:
            analysis = analyzer.analyze_article(article)
            
            if analysis.has_violation:
                print(f"✅ INCIDENT DETECTED:")
                print(f"   📋 Category: {analysis.category}")
                print(f"   🏷️  Type: {analysis.incident_type}")
                print(f"   📅 Date: {analysis.incident_date}")
                print(f"   ⚠️  Severity: {analysis.severity}")
                print(f"   📝 Description: {analysis.description}")
                
                # Store for summary
                results.append({
                    'title': article.title,
                    'category': analysis.category,
                    'type': analysis.incident_type,
                    'date': analysis.incident_date,
                    'severity': analysis.severity
                })
            else:
                print(f"❌ NO INCIDENT DETECTED")
                if analysis.error:
                    print(f"   Error: {analysis.error}")
                
        except Exception as e:
            print(f"❌ ANALYSIS FAILED: {e}")
        
        print("-" * 70)
    
    # Summary
    print("\n📊 DEEPSEEK CATEGORIZATION SUMMARY:")
    print("=" * 70)
    
    if results:
        categories = {}
        types = {}
        severities = {}
        
        for result in results:
            cat = result['category']
            typ = result['type']
            sev = result['severity']
            
            categories[cat] = categories.get(cat, 0) + 1
            types[typ] = types.get(typ, 0) + 1
            severities[sev] = severities.get(sev, 0) + 1
        
        print(f"Total incidents detected: {len(results)}")
        print(f"Categories: {dict(categories)}")
        print(f"Types: {dict(types)}")
        print(f"Severities: {dict(severities)}")
        
        print(f"\n🎯 DETAILED RESULTS:")
        for i, result in enumerate(results, 1):
            print(f"{i}. {result['category']} - {result['type']} ({result['severity']})")
            print(f"   📰 {result['title']}")
            print(f"   📅 {result['date']}")
    
    else:
        print("❌ No incidents were detected in any sample articles")
        print("This might indicate an issue with the DeepSeek model or prompt")
    
    # Show analyzer stats
    stats = analyzer.get_stats()
    print(f"\n📈 ANALYZER STATS:")
    print(f"   Model used: {stats['model_used']}")
    print(f"   Analyses performed: {stats['analyses_performed']}")
    print(f"   API endpoint: {stats['api_endpoint']}")

if __name__ == "__main__":
    test_deepseek_categorization()