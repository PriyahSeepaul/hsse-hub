"""Simple script to test OpenAI API connection"""

import os
import requests
import json

def test_openai_api():
    """Test OpenAI API connection"""
    
    api_key = os.getenv('OPENAI_API_KEY')
    
    if not api_key:
        print("❌ No API key found")
        return
    
    print(f"🔑 API Key: {api_key[:20]}...")
    
    # Test with gpt-3.5-turbo first (more reliable)
    for model in ["gpt-3.5-turbo", "gpt-4"]:
        print(f"\n🧪 Testing model: {model}")
        
        try:
            response = requests.post(
                "https://api.openai.com/v1/chat/completions",
                headers={
                    "Authorization": f"Bearer {api_key}",
                    "Content-Type": "application/json"
                },
                json={
                    "model": model,
                    "messages": [{"role": "user", "content": "Hello, test message"}],
                    "max_tokens": 10
                },
                timeout=30
            )
            
            print(f"📊 Status Code: {response.status_code}")
            
            if response.status_code == 200:
                data = response.json()
                message = data['choices'][0]['message']['content']
                print(f"✅ Success! Response: {message}")
            else:
                print(f"❌ Error: {response.status_code}")
                print(f"Response: {response.text}")
                
        except Exception as e:
            print(f"❌ Exception: {e}")

if __name__ == "__main__":
    test_openai_api()