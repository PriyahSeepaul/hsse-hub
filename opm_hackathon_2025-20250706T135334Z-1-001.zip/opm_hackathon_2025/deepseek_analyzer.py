"""DeepSeek analyzer for HSSE incident categorization using Ollama"""

import json
import requests
from typing import Dict, Any
from models import NewsArticle, ViolationAnalysis

class DeepSeekHSSEAnalyzer:
    """Analyze news articles for HSSE incidents using local DeepSeek model via Ollama"""
    
    def __init__(self, model_name: str = "deepseek-r1:8b", ollama_url: str = "http://localhost:11434"):
        self.model_name = model_name
        self.ollama_url = ollama_url
        self.api_endpoint = f"{ollama_url}/api/generate"
        self.analysis_count = 0
        
        # Test connection
        self._test_connection()
    
    def _test_connection(self):
        """Test if Ollama is accessible"""
        try:
            response = requests.get(f"{self.ollama_url}/api/tags", timeout=5)
            response.raise_for_status()
            
            models = response.json().get('models', [])
            model_names = [model['name'] for model in models]
            
            if self.model_name not in model_names:
                print(f"⚠️  Warning: Model '{self.model_name}' not found in available models: {model_names}")
                print(f"Available models: {model_names}")
            else:
                print(f"✅ Connected to Ollama. Using model: {self.model_name}")
                
        except Exception as e:
            print(f"❌ Error connecting to Ollama: {e}")
            print(f"Make sure Ollama is running: ollama serve")
    
    def analyze_article(self, article: NewsArticle) -> ViolationAnalysis:
        """Analyze a news article for HSSE incidents and categorize"""
        try:
            prompt = self._prepare_prompt(article)
            response = self._call_deepseek_api(prompt)
            analysis = self._parse_response(response, article)
            
            self.analysis_count += 1
            return analysis
            
        except Exception as e:
            return ViolationAnalysis(
                has_violation=False,
                error=f"Analysis failed: {str(e)}"
            )
    
    def _prepare_prompt(self, article: NewsArticle) -> str:
        """Prepare prompt for DeepSeek analysis"""
        
        system_instructions = """You are an expert HSSE (Health, Safety, Security, Environment) analyst specializing in incident categorization for Guyana's workplace safety monitoring system.

Your task is to analyze news articles and categorize HSSE incidents according to these specific definitions:

CATEGORIES (choose ONE - focus on the PRIMARY/most significant incident):
1. "Near Miss" - An unplanned event that did not result in injury or damage, but had the potential to.
2. "Minor Incident" - Resulted in no or minor injury, damage, or environmental impact. No time lost.
3. "Recordable Incident" - Requires medical treatment beyond first aid, or causes restricted work.
4. "Lost Time Incident" - Injury that causes the worker to miss at least one full workday.
5. "Fatality" - Incident results in death.
6. "Major Environmental Spill" - Release of hazardous material causing significant environmental harm.

TYPES (choose ONE - the primary nature of the incident):
1. "Injury/Illness" - Worker injury or health issue
2. "Property Damage" - Damage to equipment, buildings, or property
3. "Environmental Incident" - Environmental contamination or harm
4. "Security Breach" - Security-related incident
5. "Unsafe Act/Condition" - Unsafe behavior or hazardous condition
6. "Fire/Explosion" - Fire or explosion incident

INSTRUCTIONS:
- If NO HSSE incident is described, respond with: {"has_incident": false}
- If an HSSE incident IS described, respond with: {"has_incident": true, "category": "category_name", "type": "type_name", "date": "YYYY-MM-DD"}
- For date: Use the incident date if mentioned, otherwise use the article publication date
- Focus on the PRIMARY incident - the most significant event described
- Use EXACT category and type names from the lists above
- Respond ONLY with valid JSON, no additional text

Context: You are analyzing news from Guyana covering construction, mining, oil & gas, manufacturing, and other industries."""
        
        # Format article for analysis
        article_text = f"""
Title: {article.title}
Source: {article.source}
Published: {article.published_date.strftime('%Y-%m-%d') if article.published_date else 'Unknown'}

Content: {article.content}

Summary: {article.summary}
"""
        
        # Combine instructions and article
        full_prompt = f"{system_instructions}\n\nAnalyze this article:\n{article_text}\n\nThink through your analysis step by step, then provide your final answer in JSON format. After your reasoning, provide ONLY the JSON response with no additional text:"
        
        return full_prompt
    
    def _call_deepseek_api(self, prompt: str) -> dict:
        """Call DeepSeek via Ollama API"""
        
        request_data = {
            "model": self.model_name,
            "prompt": prompt,
            "stream": False,
            "options": {
                "temperature": 0.1,
                "num_predict": 1000,  # Increased to allow full response
                "stop": [],  # Remove stop tokens to allow full reasoning
                "top_k": 10,
                "top_p": 0.9
            }
        }
        
        response = requests.post(
            self.api_endpoint,
            json=request_data,
            timeout=120  # Increased timeout for reasoning model
        )
        
        response.raise_for_status()
        return response.json()
    
    def _parse_response(self, response: dict, article: NewsArticle) -> ViolationAnalysis:
        """Parse DeepSeek response into ViolationAnalysis object"""
        try:
            # Extract the generated text
            generated_text = response.get('response', '').strip()
            
            print(f"🤖 DeepSeek raw response: {generated_text[:200]}...")  # Debug output (truncated)
            
            # DeepSeek-R1 shows reasoning in <think> tags, we need to look for the actual answer
            # Check if the response is incomplete (only shows thinking)
            if generated_text.startswith('<think>') and not generated_text.endswith('</think>'):
                # Response was cut off during thinking phase, let's try again with different parameters
                return ViolationAnalysis(
                    has_violation=False,
                    error="DeepSeek response incomplete - only showing reasoning phase"
                )
            
            # Look for JSON after the thinking phase
            if '</think>' in generated_text:
                # Extract text after the thinking phase
                think_end = generated_text.find('</think>') + 8
                actual_response = generated_text[think_end:].strip()
            else:
                actual_response = generated_text
            
            # Clean up the response and find JSON
            if '{' in actual_response:
                json_start = actual_response.find('{')
                json_end = actual_response.rfind('}') + 1
                json_text = actual_response[json_start:json_end]
            else:
                # No JSON found, try to extract from the thinking process
                if 'has_incident' in generated_text:
                    # Try to find JSON-like content within the thinking
                    import re
                    json_pattern = r'\{[^}]*"has_incident"[^}]*\}'
                    matches = re.findall(json_pattern, generated_text)
                    if matches:
                        json_text = matches[-1]  # Take the last match
                    else:
                        json_text = '{"has_incident": false}'
                else:
                    json_text = '{"has_incident": false}'
            
            # Parse JSON
            analysis_data = json.loads(json_text)
            
            # Check if incident was found
            if not analysis_data.get('has_incident', False):
                return ViolationAnalysis(
                    has_violation=False,
                    description="No HSSE incident detected in article"
                )
            
            # Extract categorization data
            category = analysis_data.get('category', '')
            incident_type = analysis_data.get('type', '')
            incident_date = analysis_data.get('date', '')
            
            # Create comprehensive analysis result
            return ViolationAnalysis(
                has_violation=True,
                violation_type=f"{category} - {incident_type}",
                severity=self._map_category_to_severity(category),
                description=f"Incident categorized as {category} of type {incident_type}",
                recommendations=self._generate_recommendations(category, incident_type),
                confidence=0.85,  # Slightly lower confidence for local model
                location="",  # Location omitted as requested
                # Store additional categorization data
                category=category,
                incident_type=incident_type,
                incident_date=incident_date
            )
            
        except (KeyError, json.JSONDecodeError) as e:
            return ViolationAnalysis(
                has_violation=False,
                error=f"Failed to parse DeepSeek response: {str(e)}. Raw response: {response.get('response', '')}"
            )
    
    def _map_category_to_severity(self, category: str) -> str:
        """Map incident category to severity level"""
        severity_map = {
            "Near Miss": "Low",
            "Minor Incident": "Low", 
            "Recordable Incident": "Medium",
            "Lost Time Incident": "High",
            "Fatality": "Critical",
            "Major Environmental Spill": "Critical"
        }
        return severity_map.get(category, "Medium")
    
    def _generate_recommendations(self, category: str, incident_type: str) -> str:
        """Generate recommendations based on category and type"""
        
        category_recommendations = {
            "Near Miss": "Investigate root cause and implement preventive measures before actual incident occurs",
            "Minor Incident": "Review safety procedures and provide additional training to prevent escalation",
            "Recordable Incident": "Conduct thorough investigation, implement corrective actions, and monitor for effectiveness",
            "Lost Time Incident": "Comprehensive investigation required, review all safety protocols and implement systematic changes",
            "Fatality": "Full investigation by relevant authorities, comprehensive safety system review and overhaul required",
            "Major Environmental Spill": "Immediate containment, environmental assessment, and long-term monitoring required"
        }
        
        type_recommendations = {
            "Injury/Illness": "Review PPE requirements, safety training, and work procedures",
            "Property Damage": "Assess equipment maintenance schedules and operational procedures",
            "Environmental Incident": "Environmental impact assessment and remediation planning",
            "Security Breach": "Review and strengthen security protocols and access controls",
            "Unsafe Act/Condition": "Immediate hazard elimination and safety culture assessment",
            "Fire/Explosion": "Emergency response review and fire prevention system assessment"
        }
        
        category_rec = category_recommendations.get(category, "")
        type_rec = type_recommendations.get(incident_type, "")
        
        return f"{category_rec}. {type_rec}".strip()
    
    def get_stats(self) -> dict:
        """Get analyzer statistics"""
        return {
            'analyses_performed': self.analysis_count,
            'model_used': self.model_name,
            'api_endpoint': self.api_endpoint
        }
    
    def switch_model(self, new_model: str):
        """Switch to a different model (e.g., from 8b to 32b)"""
        self.model_name = new_model
        print(f"🔄 Switched to model: {new_model}")
        self._test_connection()