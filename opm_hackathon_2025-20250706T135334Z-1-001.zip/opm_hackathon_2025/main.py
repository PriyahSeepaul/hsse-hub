"""Enhanced main orchestrator with incident categorization"""

import time
from typing import List, Tuple
from scrapers.rss_news_scraper import RSSNewsScraper
from analyzer import HSSEIncidentAnalyzer
from models import NewsArticle, ViolationAnalysis, IncidentCategorization
from config import Config

class HSSENewsScraperOrchestrator:
    """Main orchestrator for the HSSE news incident detection and categorization system"""
    
    def __init__(self, openai_api_key: str = None):
        self.scrapers = []
        self.analyzer = HSSEIncidentAnalyzer(openai_api_key)
        
        # Initialize scrapers for each news site
        for site_key, site_config in Config.NEWS_SITES.items():
            scraper = RSSNewsScraper(site_config)
            self.scrapers.append(scraper)
    
    def run(self, limit_per_site: int = 25) -> List[Tuple[NewsArticle, ViolationAnalysis]]:
        """Run the complete news scraping and analysis pipeline"""
        print("🚀 Starting HSSE News Incident Detection & Categorization System for Guyana...")
        print(f"📰 Monitoring {len(self.scrapers)} news sources")
        
        # Scrape articles
        all_articles = self._scrape_articles(limit_per_site)
        print(f"📊 Found {len(all_articles)} HSSE-relevant articles")
        
        # Analyze and categorize articles
        incidents = self._analyze_articles(all_articles)
        print(f"⚠️  Identified {len(incidents)} HSSE incidents")
        
        # Generate summary
        self._print_summary(incidents)
        
        return incidents
    
    def _scrape_articles(self, limit_per_site: int) -> List[NewsArticle]:
        """Scrape articles from all news sources"""
        all_articles = []
        
        for scraper in self.scrapers:
            print(f"🔍 Scraping {scraper.name}...")
            try:
                articles = scraper.scrape_articles(limit_per_site)
                all_articles.extend(articles)
                print(f"   ✓ Found {len(articles)} relevant articles")
            except Exception as e:
                print(f"   ✗ Error scraping {scraper.name}: {e}")
            
            time.sleep(Config.REQUEST_DELAY)
        
        return all_articles
    
    def _analyze_articles(self, articles: List[NewsArticle]) -> List[Tuple[NewsArticle, ViolationAnalysis]]:
        """Analyze articles for incidents and categorize them"""
        incidents = []
        
        for i, article in enumerate(articles):
            print(f"🔬 Analyzing article {i+1}/{len(articles)}: {article.title[:50]}...")
            
            analysis = self.analyzer.analyze_article(article)
            
            if analysis.has_violation:
                incidents.append((article, analysis))
                print(f"   ⚠️  Incident: {analysis.category} - {analysis.incident_type}")
            else:
                print(f"   ✓ No incidents detected")
            
            time.sleep(Config.REQUEST_DELAY)
        
        return incidents
    
    def _print_summary(self, incidents: List[Tuple[NewsArticle, ViolationAnalysis]]):
        """Print summary of findings with categorization"""
        print("\n" + "="*70)
        print("🎯 HSSE INCIDENT DETECTION & CATEGORIZATION SUMMARY")
        print("="*70)
        
        if not incidents:
            print("✅ No HSSE incidents detected in recent news!")
            return
        
        # Statistics by category
        category_counts = {}
        type_counts = {}
        
        for article, analysis in incidents:
            category = analysis.category
            incident_type = analysis.incident_type
            
            category_counts[category] = category_counts.get(category, 0) + 1
            type_counts[incident_type] = type_counts.get(incident_type, 0) + 1
        
        print(f"📊 STATISTICS:")
        print(f"   Total incidents: {len(incidents)}")
        print(f"   By category: {dict(category_counts)}")
        print(f"   By type: {dict(type_counts)}")
        
        # Show incidents
        print(f"\n🔍 DETAILED INCIDENTS:")
        for i, (article, analysis) in enumerate(incidents, 1):
            print(f"\n{i}. {analysis.category} - {analysis.incident_type}")
            print(f"   📰 Source: {article.source}")
            print(f"   📅 Date: {analysis.incident_date}")
            print(f"   📝 Title: {article.title}")
            print(f"   💡 Description: {analysis.description}")
            print(f"   🎯 Recommendations: {analysis.recommendations}")
            print(f"   🔗 URL: {article.url}")
    
    def export_results(self, incidents: List[Tuple[NewsArticle, ViolationAnalysis]]) -> dict:
        """Export results with both detailed and categorized data"""
        detailed_results = []
        categorized_results = []
        
        for article, analysis in incidents:
            # Detailed result (existing format)
            detailed_results.append({
                'article': {
                    'title': article.title,
                    'content': article.content,
                    'url': article.url,
                    'source': article.source,
                    'published_date': article.published_date.isoformat() if article.published_date else None,
                    'images': article.images,
                    'summary': article.summary
                },
                'analysis': {
                    'violation_type': analysis.violation_type,
                    'severity': analysis.severity,
                    'description': analysis.description,
                    'recommendations': analysis.recommendations,
                    'confidence': analysis.confidence,
                    'category': analysis.category,
                    'incident_type': analysis.incident_type,
                    'incident_date': analysis.incident_date
                }
            })
            
            # Clean categorized result (for database)
            categorized_results.append({
                'article_url': article.url,
                'article_title': article.title,
                'source': article.source,
                'category': analysis.category,
                'type': analysis.incident_type,
                'date': analysis.incident_date
            })
        
        return {
            'total_incidents': len(incidents),
            'detailed_results': detailed_results,
            'categorized_results': categorized_results  # Clean data for database
        }
    
    def export_for_database(self, incidents: List[Tuple[NewsArticle, ViolationAnalysis]]) -> List[dict]:
        """Export clean categorized data specifically for database integration"""
        database_records = []
        
        for article, analysis in incidents:
            database_records.append({
                'article_url': article.url,
                'article_title': article.title,
                'source': article.source,
                'published_date': article.published_date.isoformat() if article.published_date else None,
                'category': analysis.category,
                'type': analysis.incident_type,
                'date': analysis.incident_date,
                'severity': analysis.severity,
                'description': analysis.description,
                'recommendations': analysis.recommendations
            })
        
        return database_records