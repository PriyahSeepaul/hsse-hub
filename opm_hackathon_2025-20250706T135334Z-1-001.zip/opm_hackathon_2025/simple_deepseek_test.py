"""Simple test to see how DeepSeek responds to basic prompts"""

import requests
import json

def test_basic_deepseek():
    """Test basic DeepSeek functionality"""
    
    print("🧪 TESTING BASIC DEEPSEEK FUNCTIONALITY")
    print("=" * 50)
    
    # Test 1: Simple question
    print("\n1. Testing simple question...")
    simple_prompt = "What is 2+2? Answer in one word."
    response = call_deepseek(simple_prompt)
    print(f"Response: {response}")
    
    # Test 2: JSON request
    print("\n2. Testing JSON response...")
    json_prompt = 'Return this in JSON format: {"answer": "hello", "number": 42}'
    response = call_deepseek(json_prompt)
    print(f"Response: {response}")
    
    # Test 3: Simple categorization
    print("\n3. Testing simple categorization...")
    cat_prompt = """A worker fell from scaffolding and was hospitalized. 
    
    Categorize this incident:
    - If it's a fatality, return: {"category": "Fatality"}
    - If it's a hospitalization, return: {"category": "Lost Time Incident"}
    - If it's minor, return: {"category": "Minor Incident"}
    
    Answer with JSON only:"""
    
    response = call_deepseek(cat_prompt)
    print(f"Response: {response}")

def call_deepseek(prompt):
    """Simple DeepSeek API call"""
    try:
        response = requests.post(
            "http://localhost:11434/api/generate",
            json={
                "model": "deepseek-r1:8b",
                "prompt": prompt,
                "stream": False,
                "options": {
                    "temperature": 0.1,
                    "num_predict": 100,  # Short response
                    "stop": ["\n"]  # Stop at newline
                }
            },
            timeout=30
        )
        
        response.raise_for_status()
        result = response.json()
        return result.get('response', '').strip()
        
    except Exception as e:
        return f"Error: {e}"

if __name__ == "__main__":
    test_basic_deepseek()