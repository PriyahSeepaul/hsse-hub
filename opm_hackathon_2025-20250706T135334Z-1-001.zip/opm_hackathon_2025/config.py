"""Configuration settings for the HSSE news scraper"""

import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

class Config:
    """Configuration class that loads settings from environment variables"""
    
    # API Keys (from environment variables)
    OPENAI_API_KEY = os.getenv('OPENAI_API_KEY')
    
    # Validate required environment variables
    if not OPENAI_API_KEY:
        raise ValueError("OPENAI_API_KEY environment variable is required")
    
    # Scraping settings
    DEFAULT_LIMIT = int(os.getenv('DEFAULT_ARTICLES_PER_SITE', '25'))
    REQUEST_DELAY = float(os.getenv('REQUEST_DELAY_SECONDS', '2.0'))
    TIMEOUT = int(os.getenv('TIMEOUT_SECONDS', '15'))
    
    # File paths
    IMAGES_DIR = 'images'
    
    # News websites configuration
    NEWS_SITES = {
        'guyana_chronicle': {
            'name': 'Guyana Chronicle',
            'base_url': 'https://guyanachronicle.com',
            'rss_url': 'https://guyanachronicle.com/feed/',
            'selectors': {
                'title': 'h1.entry-title, h1.post-title',
                'content': '.entry-content, .post-content, article',
                'image': '.entry-content img, .post-content img',
                'date': '.entry-date, .post-date'
            }
        },
        'kaieteur_news': {
            'name': 'Kaieteur News',
            'base_url': 'https://www.kaieteurnewsonline.com',
            'rss_url': 'https://www.kaieteurnewsonline.com/feed/',
            'selectors': {
                'title': 'h1.entry-title, h1.post-title',
                'content': '.entry-content, .post-content',
                'image': '.entry-content img, .post-content img',
                'date': '.entry-date, .post-date'
            }
        },
        'stabroek_news': {
            'name': 'Stabroek News',
            'base_url': 'https://www.stabroeknews.com',
            'rss_url': 'https://www.stabroeknews.com/feed/',
            'selectors': {
                'title': 'h1.entry-title, h1.post-title',
                'content': '.entry-content, .post-content',
                'image': '.entry-content img, .post-content img',
                'date': '.entry-date, .post-date'
            }
        },
        'newsroom_gy': {
            'name': 'Newsroom Guyana',
            'base_url': 'https://newsroom.gy',
            'rss_url': 'https://newsroom.gy/feed/',
            'selectors': {
                'title': 'h1.entry-title, h1.post-title',
                'content': '.entry-content, .post-content',
                'image': '.entry-content img, .post-content img',
                'date': '.entry-date, .post-date'
            }
        }
    }
    
    # Comprehensive HSSE Keywords
    HSSE_KEYWORDS = {
        'construction_infrastructure': [
            'construction', 'building', 'infrastructure', 'roadwork', 'bridge', 'excavation',
            'contractor', 'subcontractor', 'site', 'project', 'development', 'renovation',
            'concrete', 'steel', 'machinery', 'equipment', 'crane', 'bulldozer', 'excavator',
            'foundation', 'scaffolding', 'roofing', 'electrical work', 'plumbing'
        ],
        'safety_equipment': [
            'helmet', 'hard hat', 'safety vest', 'harness', 'gloves', 'boots', 'goggles',
            'PPE', 'personal protective equipment', 'safety gear', 'protective clothing',
            'respirator', 'mask', 'earplugs', 'safety line', 'fall protection'
        ],
        'incidents_accidents': [
            'accident', 'incident', 'injury', 'injured', 'hurt', 'hospitalized', 'fatality',
            'collapse', 'fall', 'struck by', 'caught in', 'electrocution', 'explosion',
            'fire', 'chemical spill', 'gas leak', 'equipment failure', 'malfunction'
        ],
        'health_safety': [
            'workplace safety', 'occupational health', 'OSHA', 'safety inspection',
            'safety violation', 'non-compliance', 'hazard', 'dangerous', 'unsafe',
            'safety training', 'safety protocol', 'emergency procedure'
        ],
        'environmental': [
            'environmental impact', 'pollution', 'contamination', 'waste disposal',
            'air quality', 'water contamination', 'noise pollution', 'dust',
            'environmental protection', 'EPA', 'environmental violation'
        ],
        'regulatory_legal': [
            'Ministry of Labour', 'safety regulations', 'building codes', 'permits',
            'inspection', 'investigation', 'fine', 'penalty', 'lawsuit', 'compensation',
            'compliance', 'violation', 'breach', 'negligence', 'liability'
        ],
        'industry_specific': [
            'mining', 'gold mining', 'bauxite', 'quarry', 'oil and gas', 'petroleum',
            'sugar industry', 'timber', 'logging', 'agriculture', 'fishing',
            'manufacturing', 'industrial', 'factory', 'plant', 'warehouse'
        ],
        'workers_employment': [
            'worker', 'employee', 'staff', 'crew', 'team', 'labor', 'workforce',
            'contractor', 'engineer', 'supervisor', 'foreman', 'safety officer',
            'union', 'workers rights', 'compensation', 'benefits'
        ],
        'medical_emergency': [
            'emergency', 'ambulance', 'hospital', 'clinic', 'medical attention',
            'first aid', 'paramedic', 'doctor', 'treatment', 'recovery',
            'disability', 'workers compensation'
        ],
        'equipment_machinery': [
            'machinery', 'equipment', 'vehicle', 'truck', 'forklift', 'generator',
            'tools', 'power tools', 'electrical equipment', 'heavy machinery',
            'maintenance', 'repair', 'inspection', 'certification', 'testing'
        ]
    }
    
    # High-priority keyword combinations
    PRIORITY_PHRASES = [
        'workplace accident', 'construction site incident', 'safety breach',
        'worker injured', 'equipment malfunction', 'building collapse',
        'safety inspection reveals', 'violations found', 'emergency response',
        'Ministry of Labour investigation', 'safety protocols ignored'
    ]