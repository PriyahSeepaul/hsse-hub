# HSSE News Scraper for Guyana

🇬🇾 **A comprehensive HSSE (Health, Safety, Security, Environment) violation detection system that monitors Guyanese news sources for workplace safety incidents and violations.**

## 🎯 Features

- **Multi-Source Monitoring**: Scrapes 4 major Guyanese news websites
- **AI-Powered Analysis**: Uses OpenAI's GPT-4 to analyze articles for HSSE violations
- **Intelligent Filtering**: Comprehensive keyword system to identify relevant content
- **Automated Reports**: Daily and weekly violation summaries
- **REST API**: Integration-ready API for databases and dashboards
- **Scalable Architecture**: Easy to add new news sources and analysis methods

## 📰 Monitored News Sources

- **Guyana Chronicle** - https://guyanachronicle.com/
- **Kaieteur News** - https://www.kaieteurnewsonline.com/
- **Stabroek News** - https://www.stabroeknews.com/
- **Newsroom Guyana** - https://newsroom.gy/

## 🔧 Installation

### Prerequisites
- Python 3.8+
- OpenAI API key

### Quick Setup
```bash
# Clone the repository
git clone https://github.com/yourusername/hsse-news-scraper.git
cd hsse-news-scraper

# Install dependencies
pip install -r requirements.txt

# Set up environment variables
export OPENAI_API_KEY="your-openai-api-key-here"

# Run the scraper
python run_scraper.py
```

### Package Installation
```bash
pip install -e .
```

## 🚀 Usage

### Command Line Interface
```bash
# Run interactive scraper
python run_scraper.py

# Or use the installed command
hsse-scraper
```

### Python API
```python
from main import HSSENewsScraperOrchestrator

# Initialize scraper
scraper = HSSENewsScraperOrchestrator(openai_api_key="your-key")

# Run analysis
violations = scraper.run(limit_per_site=25)

# Export results
export_data = scraper.export_results(violations)
```

### REST API
```bash
# Start the API server
python api/flask_api.py

# Run a scan
curl -X POST http://localhost:5000/api/scan \
  -H "Content-Type: application/json" \
  -d '{"limit": 20}'

# Check status
curl http://localhost:5000/api/status
```

## 📊 What It Detects

### HSSE Violation Types
- **Construction Safety**: Site accidents, PPE violations, fall protection issues
- **Equipment Safety**: Machinery failures, maintenance violations
- **Environmental**: Pollution, contamination, waste disposal violations
- **Regulatory**: Ministry of Labour violations, building code breaches
- **Industrial**: Mining accidents, oil & gas incidents, factory safety

### Industry Coverage
- Construction & Infrastructure
- Mining (Gold, Bauxite, Quarrying)
- Oil & Gas
- Manufacturing
- Agriculture
- Transportation

## 🏗️ Architecture

```
hsse-news-scraper/
├── config.py              # Configuration and keywords
├── models.py              # Data models
├── utils.py               # Utility functions
├── analyzer.py            # ChatGPT integration
├── main.py                # Main orchestrator
├── run_scraper.py         # CLI interface
├── scrapers/
│   ├── base_news_scraper.py
│   └── rss_news_scraper.py
├── api/
│   └── flask_api.py       # REST API
├── monitoring/
│   └── daily_report.py    # Automated reporting
└── tests/
    ├── test_keyword_matching.py
    └── test_scrapers.py
```

## 🔍 Keyword System

The system uses a comprehensive keyword system covering:

- **Construction**: construction, building, site, crane, scaffolding
- **Safety Equipment**: PPE, hard hat, safety vest, harness
- **Incidents**: accident, injury, collapse, explosion, fire
- **Regulatory**: Ministry of Labour, safety inspection, violation
- **Environmental**: pollution, contamination, EPA
- **Industry-Specific**: mining, oil and gas, manufacturing

## 📈 Output Format

### Violation Analysis
```json
{
  "has_violation": true,
  "violation_type": "PPE Violation",
  "severity": "High",
  "description": "Workers found without proper safety equipment",
  "recommendations": "Implement mandatory PPE checks before site entry",
  "confidence": 0.85,
  "affected_workers": 5,
  "location": "Georgetown construction site"
}
```

### Export Data
```json
{
  "timestamp": "2025-07-05T10:30:00",
  "total_violations": 3,
  "violations": [
    {
      "article": {
        "title": "Construction accident injures worker",
        "content": "...",
        "url": "https://...",
        "source": "Stabroek News"
      },
      "analysis": {
        "violation_type": "Fall Protection",
        "severity": "Critical",
        "description": "...",
        "recommendations": "..."
      }
    }
  ]
}
```

## 🤖 Automation

### Daily Reports
```bash
# Run daily monitoring
python monitoring/daily_report.py
```

### Scheduled Monitoring
The system can run automated daily reports at 8 AM and weekly summaries on Sundays.

## 🧪 Testing

```bash
# Run tests
python -m pytest tests/

# Test keyword matching
python tests/test_keyword_matching.py

# Test scrapers
python tests/test_scrapers.py
```

## 📋 Configuration

### Environment Variables
```bash
OPENAI_API_KEY=your-openai-api-key-here
FLASK_DEBUG=True
LOG_LEVEL=INFO
```

### Adding New News Sources
Edit `config.py` to add new news sites:

```python
'new_site': {
    'name': 'New Site Name',
    'base_url': 'https://example.com',
    'rss_url': 'https://example.com/feed/',
    'selectors': {
        'title': 'h1.title',
        'content': '.content',
        'image': '.content img',
        'date': '.date'
    }
}
```

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests
5. Submit a pull request

## 📜 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🆘 Support

For issues, questions, or feature requests:
- Open an issue on GitHub
- Email: support@example.com

## 🙏 Acknowledgments

- OpenAI for GPT-4 analysis capabilities
- Guyanese news organizations for their reporting
- Python community for excellent libraries

---

**Built for improving workplace safety in Guyana through intelligent news monitoring** 🇬🇾