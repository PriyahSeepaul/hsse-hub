"""Enhanced ChatGPT analyzer for HSSE incident categorization"""

import json
import requests
from typing import Dict, Any
from models import NewsArticle, ViolationAnalysis
from config import Config

class HSSEIncidentAnalyzer:
    """Analyze news articles for HSSE incidents and categorize them"""
    
    def __init__(self, api_key: str = None):
        self.api_key = api_key or Config.OPENAI_API_KEY
        self.analysis_count = 0
    
    def analyze_article(self, article: NewsArticle) -> ViolationAnalysis:
        """Analyze a news article for HSSE incidents and categorize"""
        try:
            messages = self._prepare_messages(article)
            response = self._call_openai_api(messages)
            analysis = self._parse_response(response, article)
            
            self.analysis_count += 1
            return analysis
            
        except Exception as e:
            return ViolationAnalysis(
                has_violation=False,
                error=f"Analysis failed: {str(e)}"
            )
    
    def _prepare_messages(self, article: NewsArticle) -> list:
        """Prepare messages for ChatGPT API with specialized categorization prompt"""
        
        system_prompt = """You are an expert HSSE (Health, Safety, Security, Environment) analyst specializing in incident categorization for Guyana's workplace safety monitoring system.

Your task is to analyze news articles and categorize HSSE incidents according to these specific definitions:

CATEGORIES (choose ONE - focus on the PRIMARY/most significant incident):
1. "Near Miss" - An unplanned event that did not result in injury or damage, but had the potential to.
2. "Minor Incident" - Resulted in no or minor injury, damage, or environmental impact. No time lost.
3. "Recordable Incident" - Requires medical treatment beyond first aid, or causes restricted work.
4. "Lost Time Incident" - Injury that causes the worker to miss at least one full workday.
5. "Fatality" - Incident results in death.
6. "Major Environmental Spill" - Release of hazardous material causing significant environmental harm.

TYPES (choose ONE - the primary nature of the incident):
1. "Injury/Illness" - Worker injury or health issue
2. "Property Damage" - Damage to equipment, buildings, or property
3. "Environmental Incident" - Environmental contamination or harm
4. "Security Breach" - Security-related incident
5. "Unsafe Act/Condition" - Unsafe behavior or hazardous condition
6. "Fire/Explosion" - Fire or explosion incident

INSTRUCTIONS:
- If NO HSSE incident is described, respond with: {"has_incident": false}
- If an HSSE incident IS described, respond with: {"has_incident": true, "category": "category_name", "type": "type_name", "date": "YYYY-MM-DD"}
- For date: Use the incident date if mentioned, otherwise use the article publication date
- Focus on the PRIMARY incident - the most significant event described
- Use EXACT category and type names from the lists above
- Respond ONLY with valid JSON, no additional text

Context: You are analyzing news from Guyana covering construction, mining, oil & gas, manufacturing, and other industries."""

        messages = [{"role": "system", "content": system_prompt}]
        
        # Format article for analysis
        article_text = f"""
Title: {article.title}
Source: {article.source}
Published: {article.published_date.strftime('%Y-%m-%d') if article.published_date else 'Unknown'}

Content: {article.content}

Summary: {article.summary}
"""
        
        messages.append({"role": "user", "content": article_text})
        
        return messages
    
    def _call_openai_api(self, messages: list) -> dict:
        """Call OpenAI API for analysis"""
        response = requests.post(
            "https://api.openai.com/v1/chat/completions",
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json"
            },
            json={
                "model": "gpt-4",
                "messages": messages,
                "max_tokens": 500,
                "temperature": 0.1
            },
            timeout=30
        )
        
        response.raise_for_status()
        return response.json()
    
    def _parse_response(self, response: dict, article: NewsArticle) -> ViolationAnalysis:
        """Parse ChatGPT response into ViolationAnalysis object"""
        try:
            content = response['choices'][0]['message']['content']
            
            # Clean up the response (remove any markdown formatting)
            content = content.strip()
            if content.startswith('```json'):
                content = content[7:-3]
            elif content.startswith('```'):
                content = content[3:-3]
            
            analysis_data = json.loads(content)
            
            # Check if incident was found
            if not analysis_data.get('has_incident', False):
                return ViolationAnalysis(
                    has_violation=False,
                    description="No HSSE incident detected in article"
                )
            
            # Extract categorization data
            category = analysis_data.get('category', '')
            incident_type = analysis_data.get('type', '')
            incident_date = analysis_data.get('date', '')
            
            # Create comprehensive analysis result
            return ViolationAnalysis(
                has_violation=True,
                violation_type=f"{category} - {incident_type}",
                severity=self._map_category_to_severity(category),
                description=f"Incident categorized as {category} of type {incident_type}",
                recommendations=self._generate_recommendations(category, incident_type),
                confidence=0.9,  # High confidence due to structured analysis
                location="",  # Location omitted as requested
                # Store additional categorization data
                category=category,
                incident_type=incident_type,
                incident_date=incident_date
            )
            
        except (KeyError, json.JSONDecodeError) as e:
            return ViolationAnalysis(
                has_violation=False,
                error=f"Failed to parse response: {str(e)}"
            )
    
    def _map_category_to_severity(self, category: str) -> str:
        """Map incident category to severity level"""
        severity_map = {
            "Near Miss": "Low",
            "Minor Incident": "Low", 
            "Recordable Incident": "Medium",
            "Lost Time Incident": "High",
            "Fatality": "Critical",
            "Major Environmental Spill": "Critical"
        }
        return severity_map.get(category, "Medium")
    
    def _generate_recommendations(self, category: str, incident_type: str) -> str:
        """Generate recommendations based on category and type"""
        
        category_recommendations = {
            "Near Miss": "Investigate root cause and implement preventive measures before actual incident occurs",
            "Minor Incident": "Review safety procedures and provide additional training to prevent escalation",
            "Recordable Incident": "Conduct thorough investigation, implement corrective actions, and monitor for effectiveness",
            "Lost Time Incident": "Comprehensive investigation required, review all safety protocols and implement systematic changes",
            "Fatality": "Full investigation by relevant authorities, comprehensive safety system review and overhaul required",
            "Major Environmental Spill": "Immediate containment, environmental assessment, and long-term monitoring required"
        }
        
        type_recommendations = {
            "Injury/Illness": "Review PPE requirements, safety training, and work procedures",
            "Property Damage": "Assess equipment maintenance schedules and operational procedures",
            "Environmental Incident": "Environmental impact assessment and remediation planning",
            "Security Breach": "Review and strengthen security protocols and access controls",
            "Unsafe Act/Condition": "Immediate hazard elimination and safety culture assessment",
            "Fire/Explosion": "Emergency response review and fire prevention system assessment"
        }
        
        category_rec = category_recommendations.get(category, "")
        type_rec = type_recommendations.get(incident_type, "")
        
        return f"{category_rec}. {type_rec}".strip()
    
    def get_stats(self) -> dict:
        """Get analyzer statistics"""
        return {
            'analyses_performed': self.analysis_count
        }
    
    def export_incident_data(self, analysis: ViolationAnalysis) -> dict:
        """Export incident data in the requested format"""
        if not analysis.has_violation:
            return None
        
        return {
            "category": getattr(analysis, 'category', ''),
            "type": getattr(analysis, 'incident_type', ''),
            "date": getattr(analysis, 'incident_date', '')
        }