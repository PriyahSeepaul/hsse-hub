"""Simplified DeepSeek analyzer that works with the reasoning model"""

import json
import requests
from typing import Dict, Any
from models import NewsArticle, ViolationAnalysis

class SimpleDeepSeekAnalyzer:
    """Simplified analyzer that works better with DeepSeek-R1's reasoning style"""
    
    def __init__(self, model_name: str = "deepseek-r1:8b"):
        self.model_name = model_name
        self.api_endpoint = "http://localhost:11434/api/generate"
        self.analysis_count = 0
    
    def analyze_article(self, article: NewsArticle) -> ViolationAnalysis:
        """Analyze article with simplified approach"""
        try:
            # Step 1: Ask if it's an HSSE incident
            is_incident = self._check_if_incident(article)
            
            if not is_incident:
                return ViolationAnalysis(
                    has_violation=False,
                    description="No HSSE incident detected"
                )
            
            # Step 2: Get category
            category = self._get_category(article)
            
            # Step 3: Get type
            incident_type = self._get_type(article)
            
            # Step 4: Get date
            incident_date = self._get_date(article)
            
            self.analysis_count += 1
            
            return ViolationAnalysis(
                has_violation=True,
                violation_type=f"{category} - {incident_type}",
                severity=self._map_severity(category),
                description=f"Incident categorized as {category} of type {incident_type}",
                recommendations=self._get_recommendations(category, incident_type),
                confidence=0.8,
                category=category,
                incident_type=incident_type,
                incident_date=incident_date
            )
            
        except Exception as e:
            return ViolationAnalysis(
                has_violation=False,
                error=f"Analysis failed: {str(e)}"
            )
    
    def _check_if_incident(self, article: NewsArticle) -> bool:
        """Check if article describes an HSSE incident"""
        prompt = f"""Article: {article.title}
Content: {article.content[:500]}...

Is this an HSSE (workplace safety) incident? Answer ONLY "YES" or "NO":"""
        
        response = self._call_deepseek_simple(prompt, max_tokens=10)
        return "YES" in response.upper()
    
    def _get_category(self, article: NewsArticle) -> str:
        """Get incident category"""
        prompt = f"""Article: {article.title}
Content: {article.content[:500]}...

What category is this incident? Choose ONE:
1. Near Miss
2. Minor Incident  
3. Recordable Incident
4. Lost Time Incident
5. Fatality
6. Major Environmental Spill

Answer with the exact category name only:"""
        
        response = self._call_deepseek_simple(prompt, max_tokens=20)
        
        # Clean up response
        categories = ["Near Miss", "Minor Incident", "Recordable Incident", 
                     "Lost Time Incident", "Fatality", "Major Environmental Spill"]
        
        for cat in categories:
            if cat.lower() in response.lower():
                return cat
        
        return "Minor Incident"  # Default
    
    def _get_type(self, article: NewsArticle) -> str:
        """Get incident type"""
        prompt = f"""Article: {article.title}
Content: {article.content[:500]}...

What type of incident is this? Choose ONE:
1. Injury/Illness
2. Property Damage
3. Environmental Incident
4. Security Breach
5. Unsafe Act/Condition
6. Fire/Explosion

Answer with the exact type name only:"""
        
        response = self._call_deepseek_simple(prompt, max_tokens=20)
        
        # Clean up response
        types = ["Injury/Illness", "Property Damage", "Environmental Incident",
                "Security Breach", "Unsafe Act/Condition", "Fire/Explosion"]
        
        for typ in types:
            if typ.lower() in response.lower():
                return typ
        
        return "Injury/Illness"  # Default
    
    def _get_date(self, article: NewsArticle) -> str:
        """Get incident date"""
        prompt = f"""Article: {article.title}
Content: {article.content[:500]}...
Published: {article.published_date.strftime('%Y-%m-%d')}

When did this incident occur? Answer in YYYY-MM-DD format only:"""
        
        response = self._call_deepseek_simple(prompt, max_tokens=15)
        
        # Look for date pattern
        import re
        date_pattern = r'\d{4}-\d{2}-\d{2}'
        match = re.search(date_pattern, response)
        
        if match:
            return match.group()
        else:
            # Use publication date as fallback
            return article.published_date.strftime('%Y-%m-%d')
    
    def _call_deepseek_simple(self, prompt: str, max_tokens: int = 50) -> str:
        """Simple DeepSeek API call with short responses"""
        try:
            response = requests.post(
                self.api_endpoint,
                json={
                    "model": self.model_name,
                    "prompt": prompt,
                    "stream": False,
                    "options": {
                        "temperature": 0.1,
                        "num_predict": max_tokens,
                        "stop": ["\n\n", "Article:", "Content:"]
                    }
                },
                timeout=30
            )
            
            response.raise_for_status()
            result = response.json()
            return result.get('response', '').strip()
            
        except Exception as e:
            print(f"API Error: {e}")
            return ""
    
    def _map_severity(self, category: str) -> str:
        """Map category to severity"""
        severity_map = {
            "Near Miss": "Low",
            "Minor Incident": "Low",
            "Recordable Incident": "Medium", 
            "Lost Time Incident": "High",
            "Fatality": "Critical",
            "Major Environmental Spill": "Critical"
        }
        return severity_map.get(category, "Medium")
    
    def _get_recommendations(self, category: str, incident_type: str) -> str:
        """Get basic recommendations"""
        if category == "Fatality":
            return "Full investigation required. Comprehensive safety review needed."
        elif category == "Lost Time Incident":
            return "Thorough investigation and safety protocol review required."
        elif category == "Recordable Incident":
            return "Investigation and corrective actions needed."
        else:
            return "Review safety procedures and implement preventive measures."
    
    def get_stats(self) -> dict:
        """Get analyzer statistics"""
        return {
            'analyses_performed': self.analysis_count,
            'model_used': self.model_name
        }