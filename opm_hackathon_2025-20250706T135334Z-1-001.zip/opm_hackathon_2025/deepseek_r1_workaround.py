"""Workaround for DeepSeek-R1 that extracts answers from reasoning"""

import requests
import json
import re
from typing import Dict, Any
from models import NewsArticle, ViolationAnalysis

class DeepSeekR1Analyzer:
    """Analyzer that works with DeepSeek-R1's reasoning output"""
    
    def __init__(self, model_name: str = "deepseek-r1:8b"):
        self.model_name = model_name
        self.api_endpoint = "http://localhost:11434/api/generate"
        self.analysis_count = 0
    
    def analyze_article(self, article: NewsArticle) -> ViolationAnalysis:
        """Analyze article by extracting answers from DeepSeek's reasoning"""
        try:
            prompt = self._create_analysis_prompt(article)
            response = self._call_deepseek_full(prompt)
            analysis = self._extract_from_reasoning(response, article)
            
            self.analysis_count += 1
            return analysis
            
        except Exception as e:
            return ViolationAnalysis(
                has_violation=False,
                error=f"Analysis failed: {str(e)}"
            )
    
    def _create_analysis_prompt(self, article: NewsArticle) -> str:
        """Create a prompt that encourages reasoning then conclusion"""
        
        return f"""You are analyzing this workplace incident article from Guyana:

Title: {article.title}
Content: {article.content[:800]}
Published: {article.published_date.strftime('%Y-%m-%d')}

Think step by step about:
1. Is this a workplace safety incident?
2. What category: Near Miss, Minor Incident, Recordable Incident, Lost Time Incident, Fatality, or Major Environmental Spill?
3. What type: Injury/Illness, Property Damage, Environmental Incident, Security Breach, Unsafe Act/Condition, or Fire/Explosion?
4. When did it happen?

After your analysis, conclude with your final categorization."""
    
    def _call_deepseek_full(self, prompt: str) -> str:
        """Call DeepSeek and get full reasoning response"""
        try:
            response = requests.post(
                self.api_endpoint,
                json={
                    "model": self.model_name,
                    "prompt": prompt,
                    "stream": False,
                    "options": {
                        "temperature": 0.1,
                        "num_predict": 2000,  # Allow full reasoning
                        "stop": []  # Don't stop early
                    }
                },
                timeout=120
            )
            
            response.raise_for_status()
            result = response.json()
            return result.get('response', '').strip()
            
        except Exception as e:
            print(f"API Error: {e}")
            return ""
    
    def _extract_from_reasoning(self, reasoning_text: str, article: NewsArticle) -> ViolationAnalysis:
        """Extract categorization from DeepSeek's reasoning text"""
        
        print(f"🤖 DeepSeek reasoning (first 500 chars): {reasoning_text[:500]}...")
        
        # Check if it's an incident
        if not self._is_incident_mentioned(reasoning_text):
            return ViolationAnalysis(
                has_violation=False,
                description="No HSSE incident detected in reasoning"
            )
        
        # Extract category
        category = self._extract_category(reasoning_text)
        
        # Extract type
        incident_type = self._extract_type(reasoning_text)
        
        # Extract or use publication date
        incident_date = self._extract_date(reasoning_text, article)
        
        return ViolationAnalysis(
            has_violation=True,
            violation_type=f"{category} - {incident_type}",
            severity=self._map_severity(category),
            description=f"Incident categorized as {category} of type {incident_type}",
            recommendations=self._get_recommendations(category, incident_type),
            confidence=0.75,  # Lower confidence due to extraction method
            category=category,
            incident_type=incident_type,
            incident_date=incident_date
        )
    
    def _is_incident_mentioned(self, text: str) -> bool:
        """Check if reasoning mentions this is an incident"""
        incident_keywords = [
            "workplace incident", "safety incident", "accident", "injury", 
            "fatality", "spill", "fire", "explosion", "unsafe", "violation"
        ]
        
        text_lower = text.lower()
        return any(keyword in text_lower for keyword in incident_keywords)
    
    def _extract_category(self, text: str) -> str:
        """Extract category from reasoning text"""
        categories = {
            "fatality": "Fatality",
            "death": "Fatality", 
            "died": "Fatality",
            "fatal": "Fatality",
            "lost time": "Lost Time Incident",
            "hospitalized": "Lost Time Incident",
            "hospital": "Lost Time Incident",
            "miss work": "Lost Time Incident",
            "recordable": "Recordable Incident",
            "medical treatment": "Recordable Incident",
            "first aid": "Recordable Incident",
            "environmental spill": "Major Environmental Spill",
            "oil spill": "Major Environmental Spill",
            "chemical spill": "Major Environmental Spill",
            "near miss": "Near Miss",
            "narrowly avoided": "Near Miss",
            "could have": "Near Miss",
            "minor": "Minor Incident"
        }
        
        text_lower = text.lower()
        
        # Check for specific patterns
        for keyword, category in categories.items():
            if keyword in text_lower:
                return category
        
        return "Minor Incident"  # Default
    
    def _extract_type(self, text: str) -> str:
        """Extract incident type from reasoning text"""
        types = {
            "injury": "Injury/Illness",
            "injured": "Injury/Illness", 
            "hurt": "Injury/Illness",
            "illness": "Injury/Illness",
            "fire": "Fire/Explosion",
            "explosion": "Fire/Explosion",
            "property damage": "Property Damage",
            "equipment damage": "Property Damage",
            "environmental": "Environmental Incident",
            "spill": "Environmental Incident",
            "contamination": "Environmental Incident",
            "security": "Security Breach",
            "unsafe": "Unsafe Act/Condition",
            "violation": "Unsafe Act/Condition"
        }
        
        text_lower = text.lower()
        
        for keyword, incident_type in types.items():
            if keyword in text_lower:
                return incident_type
        
        return "Injury/Illness"  # Default
    
    def _extract_date(self, text: str, article: NewsArticle) -> str:
        """Extract date from reasoning or use publication date"""
        
        # Look for date patterns in reasoning
        date_pattern = r'\d{4}-\d{2}-\d{2}'
        match = re.search(date_pattern, text)
        
        if match:
            return match.group()
        
        # Look for relative dates
        if "yesterday" in text.lower():
            from datetime import datetime, timedelta
            yesterday = article.published_date - timedelta(days=1)
            return yesterday.strftime('%Y-%m-%d')
        
        # Use publication date as fallback
        return article.published_date.strftime('%Y-%m-%d')
    
    def _map_severity(self, category: str) -> str:
        """Map category to severity"""
        severity_map = {
            "Near Miss": "Low",
            "Minor Incident": "Low",
            "Recordable Incident": "Medium",
            "Lost Time Incident": "High", 
            "Fatality": "Critical",
            "Major Environmental Spill": "Critical"
        }
        return severity_map.get(category, "Medium")
    
    def _get_recommendations(self, category: str, incident_type: str) -> str:
        """Generate recommendations"""
        if category == "Fatality":
            return "Full investigation required. Comprehensive safety review needed."
        elif category == "Lost Time Incident":
            return "Thorough investigation and safety protocol review required."
        elif category == "Recordable Incident":
            return "Investigation and corrective actions needed."
        else:
            return "Review safety procedures and implement preventive measures."
    
    def get_stats(self) -> dict:
        """Get analyzer statistics"""
        return {
            'analyses_performed': self.analysis_count,
            'model_used': self.model_name
        }