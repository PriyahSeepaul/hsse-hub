"""Utility functions for the HSSE news scraper"""

import re
import requests
from typing import List, Optional
from datetime import datetime
from config import Config

class KeywordMatcher:
    """Handle keyword matching and relevance scoring"""
    
    def __init__(self):
        self.all_keywords = []
        self.priority_phrases = Config.PRIORITY_PHRASES
        
        # Flatten all keywords
        for category, keywords in Config.HSSE_KEYWORDS.items():
            self.all_keywords.extend(keywords)
    
    def is_hsse_relevant(self, text: str) -> bool:
        """Check if text is relevant to HSSE topics"""
        text_lower = text.lower()
        
        # Check for priority phrases first (higher weight)
        for phrase in self.priority_phrases:
            if phrase.lower() in text_lower:
                return True
        
        # Check for individual keywords
        keyword_count = sum(1 for keyword in self.all_keywords if keyword.lower() in text_lower)
        return keyword_count >= 2  # Require at least 2 keywords
    
    def calculate_relevance_score(self, text: str) -> float:
        """Calculate relevance score (0-1) based on keyword matches"""
        text_lower = text.lower()
        score = 0.0
        
        # Priority phrases worth more
        for phrase in self.priority_phrases:
            if phrase.lower() in text_lower:
                score += 0.3
        
        # Individual keywords
        for keyword in self.all_keywords:
            if keyword.lower() in text_lower:
                score += 0.1
        
        return min(score, 1.0)  # Cap at 1.0
    
    def extract_keywords_found(self, text: str) -> List[str]:
        """Extract all HSSE keywords found in text"""
        text_lower = text.lower()
        found_keywords = []
        
        for keyword in self.all_keywords:
            if keyword.lower() in text_lower:
                found_keywords.append(keyword)
        
        for phrase in self.priority_phrases:
            if phrase.lower() in text_lower:
                found_keywords.append(phrase)
        
        return found_keywords

class TextProcessor:
    """Process and clean text content"""
    
    @staticmethod
    def clean_text(text: str) -> str:
        """Clean and normalize text"""
        if not text:
            return ""
        
        # Remove extra whitespace
        text = re.sub(r'\s+', ' ', text)
        
        # Remove special characters but keep punctuation
        text = re.sub(r'[^\w\s\.,!?;:-]', '', text)
        
        return text.strip()
    
    @staticmethod
    def extract_summary(text: str, max_length: int = 300) -> str:
        """Extract a summary from text"""
        if len(text) <= max_length:
            return text
        
        # Find the first few sentences
        sentences = re.split(r'[.!?]+', text)
        summary = ""
        
        for sentence in sentences:
            if len(summary + sentence) <= max_length:
                summary += sentence + ". "
            else:
                break
        
        return summary.strip()

class URLHandler:
    """Handle URL processing and validation"""
    
    @staticmethod
    def is_valid_url(url: str) -> bool:
        """Check if URL is valid"""
        return url.startswith(('http://', 'https://'))
    
    @staticmethod
    def make_absolute_url(url: str, base_url: str) -> str:
        """Convert relative URL to absolute"""
        if URLHandler.is_valid_url(url):
            return url
        
        if url.startswith('/'):
            return base_url + url
        
        return base_url + '/' + url