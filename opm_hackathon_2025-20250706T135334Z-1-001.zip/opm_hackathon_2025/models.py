"""Enhanced data models for the HSSE news scraper with categorization"""

from dataclasses import dataclass
from typing import Optional, List, Dict, Any
from datetime import datetime

@dataclass
class NewsArticle:
    """Represents a news article"""
    title: str
    content: str
    url: str
    source: str
    published_date: Optional[datetime] = None
    images: List[str] = None
    summary: str = ''
    
    def __post_init__(self):
        if self.images is None:
            self.images = []
        if not self.published_date:
            self.published_date = datetime.now()

@dataclass
class ViolationAnalysis:
    """Represents the enhanced analysis result with categorization"""
    has_violation: bool
    violation_type: str = ''
    severity: str = ''
    description: str = ''
    recommendations: str = ''
    confidence: float = 0.0
    affected_workers: int = 0
    location: str = ''
    error: Optional[str] = None
    
    # Enhanced categorization fields
    category: str = ''           # Near Miss, Minor Incident, etc.
    incident_type: str = ''      # Injury/Illness, Property Damage, etc.
    incident_date: str = ''      # YYYY-MM-DD format
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ViolationAnalysis':
        return cls(
            has_violation=data.get('has_violation', False),
            violation_type=data.get('violation_type', ''),
            severity=data.get('severity', ''),
            description=data.get('description', ''),
            recommendations=data.get('recommendations', ''),
            confidence=data.get('confidence', 0.0),
            affected_workers=data.get('affected_workers', 0),
            location=data.get('location', ''),
            error=data.get('error'),
            category=data.get('category', ''),
            incident_type=data.get('incident_type', ''),
            incident_date=data.get('incident_date', '')
        )

@dataclass
class IncidentCategorization:
    """Represents the clean categorization output for database"""
    category: str
    type: str
    date: str
    
    def to_dict(self) -> Dict[str, str]:
        return {
            "category": self.category,
            "type": self.type,
            "date": self.date
        }