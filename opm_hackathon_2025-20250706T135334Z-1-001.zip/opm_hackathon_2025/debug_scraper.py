"""Debug script to test AI categorization with hardcoded sample articles"""

import os
from datetime import datetime
from models import NewsArticle
from analyzer import HSSEIncidentAnalyzer

def create_sample_articles():
    """Create hardcoded sample articles for testing"""
    
    sample_articles = [
        NewsArticle(
            title="Construction Worker Hospitalized After Fall at Georgetown Site",
            content="A construction worker was rushed to Georgetown Public Hospital after falling from scaffolding at a building site on Regent Street yesterday. The worker, identified as John Smith, 32, fell approximately 15 feet and sustained serious injuries to his back and legs. He is expected to remain hospitalized for several days. The Ministry of Labour has launched an investigation into the incident. Site supervisor reported that the worker was wearing a safety harness at the time of the fall.",
            url="https://guyanachronicle.com/sample1",
            source="Guyana Chronicle",
            published_date=datetime(2025, 1, 15),
            summary="Construction worker hospitalized after fall from scaffolding at Georgetown construction site."
        ),
        
        NewsArticle(
            title="Minor Fire Extinguished at Bauxite Processing Plant",
            content="A small fire broke out at the Berbice Bauxite processing facility early this morning but was quickly contained by the site's emergency response team. No injuries were reported, and the fire was extinguished within 30 minutes. The incident occurred in the electrical equipment room and caused minimal damage to machinery. Operations resumed normal schedule after safety inspections. The company's safety officer stated that all emergency protocols were followed correctly.",
            url="https://stabroeknews.com/sample2", 
            source="Stabroek News",
            published_date=datetime(2025, 1, 14),
            summary="Minor fire at bauxite plant quickly contained with no injuries."
        ),
        
        NewsArticle(
            title="Oil Spill Contained at Offshore Platform",
            content="ExxonMobil reported a significant oil spill at their Liza Unity platform yesterday, releasing approximately 2,000 barrels of crude oil into the ocean. The company activated emergency response procedures and deployed containment booms. The Environmental Protection Agency has been notified and is monitoring the situation. Marine wildlife in the area may be affected, and cleanup operations are ongoing. The cause of the spill is under investigation.",
            url="https://newsroom.gy/sample3",
            source="Newsroom Guyana", 
            published_date=datetime(2025, 1, 13),
            summary="Major oil spill at offshore platform prompts emergency response."
        ),
        
        NewsArticle(
            title="Mining Equipment Malfunction Narrowly Avoids Serious Accident",
            content="A hydraulic excavator at the Aurora Gold Mine experienced a sudden brake failure while operating near the pit edge yesterday. The quick thinking of operator Michael Johnson prevented what could have been a catastrophic accident. Johnson was able to steer the machine away from the edge and bring it to a safe stop. No injuries occurred and no equipment was damaged. The incident has prompted a review of all heavy machinery maintenance schedules.",
            url="https://kaieteurnewsonline.com/sample4",
            source="Kaieteur News",
            published_date=datetime(2025, 1, 12),
            summary="Mining equipment brake failure nearly causes serious accident but operator's quick action prevents incident."
        ),
        
        NewsArticle(
            title="Factory Worker Dies in Machinery Accident",
            content="A tragic accident at the Diamond Sugar Factory claimed the life of a 45-year-old worker yesterday evening. The worker, whose name has not been released pending family notification, was caught in conveyor belt machinery during routine maintenance. Emergency services responded immediately but the worker was pronounced dead at the scene. The factory has been temporarily shut down while authorities investigate. This is the second workplace fatality at the facility in three years.",
            url="https://guyanachronicle.com/sample5",
            source="Guyana Chronicle",
            published_date=datetime(2025, 1, 11),
            summary="Factory worker dies in machinery accident during maintenance."
        ),
        
        NewsArticle(
            title="Construction Site Safety Violation Discovered During Inspection",
            content="Ministry of Labour inspectors discovered multiple safety violations at a construction site in New Amsterdam during a routine inspection. Workers were found operating without proper safety equipment, including hard hats and safety harnesses. Several workers were also observed working on elevated platforms without proper fall protection. The site has been issued citations and work has been suspended until all safety measures are properly implemented. The contractor faces potential fines.",
            url="https://stabroeknews.com/sample6",
            source="Stabroek News", 
            published_date=datetime(2025, 1, 10),
            summary="Multiple safety violations found at construction site during inspection."
        )
    ]
    
    return sample_articles

def test_ai_categorization():
    """Test ChatGPT categorization with sample articles"""
    
    # Check for API key
    api_key = os.getenv('OPENAI_API_KEY')
    if not api_key:
        print("❌ Error: OPENAI_API_KEY environment variable not set")
        return
    
    print("🤖 TESTING AI CATEGORIZATION WITH SAMPLE ARTICLES")
    print("=" * 60)
    print("Testing how ChatGPT categorizes different types of HSSE incidents...")
    print()
    
    # Create analyzer
    analyzer = HSSEIncidentAnalyzer(api_key)
    
    # Get sample articles
    sample_articles = create_sample_articles()
    
    results = []
    
    for i, article in enumerate(sample_articles, 1):
        print(f"🔬 Testing Article {i}/{len(sample_articles)}")
        print(f"📰 Title: {article.title}")
        print(f"📅 Date: {article.published_date.strftime('%Y-%m-%d')}")
        print(f"🔗 Source: {article.source}")
        
        # Analyze with ChatGPT
        try:
            analysis = analyzer.analyze_article(article)
            
            if analysis.has_violation:
                print(f"✅ INCIDENT DETECTED:")
                print(f"   📋 Category: {analysis.category}")
                print(f"   🏷️  Type: {analysis.incident_type}")
                print(f"   📅 Date: {analysis.incident_date}")
                print(f"   ⚠️  Severity: {analysis.severity}")
                print(f"   📝 Description: {analysis.description}")
                
                # Store for summary
                results.append({
                    'title': article.title,
                    'category': analysis.category,
                    'type': analysis.incident_type,
                    'date': analysis.incident_date,
                    'severity': analysis.severity
                })
            else:
                print(f"❌ NO INCIDENT DETECTED")
                if analysis.error:
                    print(f"   Error: {analysis.error}")
                
        except Exception as e:
            print(f"❌ ANALYSIS FAILED: {e}")
        
        print("-" * 60)
    
    # Summary
    print("\n📊 CATEGORIZATION SUMMARY:")
    print("=" * 60)
    
    if results:
        categories = {}
        types = {}
        severities = {}
        
        for result in results:
            cat = result['category']
            typ = result['type']
            sev = result['severity']
            
            categories[cat] = categories.get(cat, 0) + 1
            types[typ] = types.get(typ, 0) + 1
            severities[sev] = severities.get(sev, 0) + 1
        
        print(f"Total incidents detected: {len(results)}")
        print(f"Categories: {dict(categories)}")
        print(f"Types: {dict(types)}")
        print(f"Severities: {dict(severities)}")
        
        print(f"\n🎯 DETAILED RESULTS:")
        for i, result in enumerate(results, 1):
            print(f"{i}. {result['category']} - {result['type']} ({result['severity']})")
            print(f"   📰 {result['title']}")
            print(f"   📅 {result['date']}")
    
    else:
        print("❌ No incidents were detected in any sample articles")
        print("This might indicate an issue with the categorization prompt")

if __name__ == "__main__":
    test_ai_categorization()